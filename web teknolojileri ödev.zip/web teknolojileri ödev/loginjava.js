function detection() {
  var username = document.getElementsByClassName("name");
  var userpass = document.getElementsByClassName("pass");
  if (username != "g191210012@hotmail.com" || userpass != 123) {
     document.getElementById("wronginfo").innerHTML = "şifreniz veya kullanıcı adınız yanlış.";
  }
}
