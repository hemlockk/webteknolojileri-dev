

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
 //var i = 0;
  var slides = document.getElementsByClassName("mySlides");
  if (n > slides.length){slideIndex = 1}
  if (n < 1){slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }

  slides[slideIndex-1].style.display = "block";
}

/* currentSlide(slidenumber);
function nextslide(n){
  slidenumber += n;
  if(slidenumber > 3){
    slidenumber = 0;
  }

}
 function currentSlide(snumber){
    var i = 0;
    var mySlides = document.getElementsByClassName("slides");
    for (var i = 0; i < snumber.length; i++) {
      slides[i].style.display = "none";
    }
    slides[snumber - 1].style.display = "inline";
}
*/
