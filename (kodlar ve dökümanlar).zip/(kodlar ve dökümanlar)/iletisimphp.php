<?php
  $un = $_POST["firstname"];
  $surname = $_POST['lastname'];
  $email_visitor = $_POST['email'];
  $message = $_POST['subject'];
  $email_subject = "siteden kullanıcı mesajı";
  $email_to = "ali.yusuf01@hotmail.com";
  $header = "From: $email_visitor";
  $email_body = "kullanıcı adı: $un $surname. \n kullanıcı maili: $email_visitor. \n kullanıcı mesajı: $message. \n";

  mail($email_to, $email_subject,$email_body,$header);
  echo "teşekürler $un iletiniz bize ulaşıcaktır \n";
  echo "bilgileriniz söyledir \nemail:$email_visitor \ntam adınız: $un $surname \n mesajınız:$message";
 ?>
