function temizle() {
  document.getElementById("fname").value = "";
  document.getElementById("lname").value = "";
  document.getElementById("meyl").value = "";
  document.getElementById("subject").value = "";


}
